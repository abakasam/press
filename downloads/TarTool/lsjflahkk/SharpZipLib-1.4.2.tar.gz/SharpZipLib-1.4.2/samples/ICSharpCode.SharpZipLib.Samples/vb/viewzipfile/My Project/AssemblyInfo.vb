Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ViewZipFile")>
<Assembly: AssemblyDescription("SharpZipLib Sample Project")>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("B1F6EDEE-BB2F-4696-81FD-047789430B68")>
