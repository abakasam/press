## Requirements
```
npm install -g git-release-notes
```

## Usage
```
git release-notes -f release-notes.json PREVIOUS..CURRENT release-notes-md.ejs
```
Where PREVIOUS is the previous release tag, and CURRENT is the current release tag
