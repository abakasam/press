ziplist
-------

Usage:


  ziplist  [filename]

  will view the headers of the zipfile [filename]